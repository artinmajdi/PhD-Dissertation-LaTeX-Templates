## NYU dissertation template
This template matches http://gsas.nyu.edu/docs/IO/4474/formattingguide.pdf.
